package com.example.dundermiflincrm;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    //variables
    private ArrayList<String> mnmNames =new ArrayList<>();
    private ArrayList<String> mnmImageURLS = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initImageBitmaps();
    }

    private void initImageBitmaps(){
        Log.d(TAG, "initImageBitmaps: preparingbitmaps.");

        mnmImageURLS.add("https://dumielauxepices.net/sites/default/files/customer-clipart-collaboration-495588-9155963.jpg");
        mnmNames.add("Customers");

        mnmImageURLS.add("https://upload.wikimedia.org/wikipedia/en/8/80/The_office_US.jpg");
        mnmNames.add("Employees");

        mnmImageURLS.add("https://cdn-wordpress.onepagecrm.com/wp-content/uploads/2017/03/meet-sales.png");
        mnmNames.add("Sales");

        initRecyclerView();
    }

    private void initRecyclerView(){
        Log.d(TAG, "initRecyclerView: init recyclerview.");
        RecyclerView recyclerView = findViewById(R.id.recyclerv_view);
        RecyclerViewAdapter adapter = new RecyclerViewAdapter(mnmNames, mnmImageURLS,this);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }
}
